SELECT COUNT(*) AS "nb_court-metrage" FROM `film` WHERE duree_min < 43 ;
