SELECT titre, resum FROM `film` WHERE `resum` like '%vincent%' ORDER BY `film`.`id_film` ASC;
