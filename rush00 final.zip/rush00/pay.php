<?php
include_once("includes/fonctions.php");
sec_session_start();
if ($_POST['Annuler'])
{
// 	<html> <div> <img  SRC="img/paiement.jpg" alt="paiement" title="CB"> </div> </html>
$_SESSION['cart'] = array();

}
else
// <html> <div> <img  SRC="img/paiement.jpg" alt="paiement" title="CB"> </div> </html>
echo "OK ! paiement directement preleve dans votre compte tous les mois <br />"
?>
