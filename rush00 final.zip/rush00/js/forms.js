function formhash(form, password) {
	// Create a new element input, this will be our hashed password field.
	if (password.value == '' || form.email.value == '') {
		alert('Vous devez remplir tout les champs');
		return false;
	}
	var p = document.createElement("input");

	// Add the new element to our form.
	form.appendChild(p);
	p.name = "p";
	p.type = "hidden";
	p.value = hex_sha512(password.value);

	// Make sure the plaintext password doesn't get sent.
	password.value = "";

	// Finally submit the form.
	form.submit();
	return true;
}

function regformhash(form, uid, email, password, conf, adress, cp, ville) {
	// Check each field has a value
	if (uid.value == '' || email.value == '' || password.value == '' || conf.value == ''|| adress.value == '' || cp.value == '' || ville.value == '') {
		alert('Vous devez remplir tout les champs');
		return false;
	}

	// Check the username
	re = /^\w+$/;
	if(!re.test(form.username.value)) {
		alert("Le pseudo doit contenir que des lettres ou underscores. Essai encore");
		form.username.focus();
		return false;
	}

	// Check that the password is sufficiently long (min 6 chars)
	// The check is duplicated below, but this is included to give more
	// specific guidance to the user
	if (password.value.length < 6) {
		alert('Le mot de passe doit contenir au moins 6 lettres. Essai encore');
		form.password.focus();
		return false;
	}

	// At least one number, one lowercase and one uppercase letter
	// At least six characters
	var re = /(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}/;
	if (!re.test(password.value)) {
		alert('Le mot de passe doit contenir au moins 1 lettre minuscule, 1 lettre majuscule et 1 chiffre. Essai encore');
		return false;
	}

	// Check password and confirmation are the same
	if (password.value != conf.value) {
		alert('Mot de passe différent de la confirmation. Essai encore');
		form.password.focus();
		return false;
	}

	// Create a new element input, this will be our hashed password field.
	var p = document.createElement("input");

	// Add the new element to our form.
	form.appendChild(p);
	p.name = "p";
	p.type = "hidden";
	p.value = hex_sha512(password.value);

	// Make sure the plaintext password doesn't get sent.
	password.value = "";
	conf.value = "";

	// Finally submit the form.
	form.submit();
	return true;
}

function resetformhash(form, email) {
	// Check each field has a value
	if (email.value == '') {
		alert('Vous devez remplir le mail');
		return false;
	}

	form.submit();
	return true;
}

function adminadd(form, name, price, stock, img, cat)
{
	if (name.value == '' || price.value == '' || stock.value == '' || img.value == '' || cat.value == '') {
		alert('Vous devez remplir tout les champs');
		return false;
	}
	re = /^(?=.*\d).{1,}$/;
	if (!re.test(stock.value)) {
		alert('Le stock doit contenir que des chiffres. Essai encore');
		return false;
	}
	re = /^(?=.*\d).{1,}$/;
	if (!re.test(price.value)) {
		alert('Le prix doit contenir que des chiffres. Essai encore');
		return false;
	}
	re = /^\w+$/;
	if (!re.test(name.value)) {
		alert('Le nom doit contenir que des lettres. Essai encore');
		return false;
	}
	form.submit();
	return true;
}



function Pformhash(form, password, conf, vare) {
	// Check each field has a value
	if (password.value == '' || conf.value == '') {
		alert('Vous devez remplir tout les champs');
		return false;
	}

	// Check that the password is sufficiently long (min 6 chars)
	// The check is duplicated below, but this is included to give more
	// specific guidance to the user
	if (password.value.length < 6) {
		alert('Le mot de passe doit contenir au moins 6 lettres. Essai encore');
		form.password.focus();
		return false;
	}

	// At least one number, one lowercase and one uppercase letter
	// At least six characters
	var re = /(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}/;
	if (!re.test(password.value)) {
		alert('Le mot de passe doit contenir au moins 1 lettre minuscule, 1 lettre majuscule et 1 chiffre. Essai encore');
		return false;
	}

	// Check password and confirmation are the same
	if (password.value != conf.value) {
		alert('Mot de passe différent de la confirmation. Essai encore');
		form.password.focus();
		return false;
	}

	// Create a new element input, this will be our hashed password field.
	var p = document.createElement("input");
	var id = document.createElement("input");

	// Add the new element to our form.
	form.appendChild(id);
	id.name = "id";
	id.type = "hidden";
	id.value = vare.value;
	form.appendChild(p);
	p.name = "p";
	p.type = "hidden";
	p.value = hex_sha512(password.value);

	// Make sure the plaintext password doesn't get sent.
	password.value = "";
	conf.value = "";

	// Finally submit the form.
	form.submit();
	return true;
}
