<?php
include_once("includes/db_connect.php");
include_once("includes/fonctions.php");
sec_session_start();
/////////////////////////////olivier////////////////////////////////
unset($_SESSION['costumerID']);
unset($_SESSION['cart']);
if (isset($_SESSION['costumerID']))
	$_POST['costumerID'] = $_SESSION['costumerID'];
////////////////////////////////////////////////////////////////////
?>
<!DOCTYPE html PUBLIC>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no" />
	<title>Slip-Shop</title>
	<link rel="stylesheet" href="styles/style.css">
	<script type="text/JavaScript" src="js/forms.js"></script>
	<script type="text/JavaScript" src="js/sha512.js"></script>
	<script>
	$(document).ready(function() {
		$("#navToggle a").click(function(e){
			e.preventDefault();

			$("header > nav").slideToggle("medium");
			$("#logo").toggleClass("menuUp menuDown");
		});

		$(window).resize(function() {
			if($( window ).width() >= "600") {
				$("header > nav").css("display", "block");

				if($("#logo").attr('class') == "menuDown") {
					$("#logo").toggleClass("menuUp menuDown");
				}
			}
			else {
				$("header > nav").css("display", "none");
			}
		});

		$("header > nav > ul > li > a").click(function(e) {
			if($( window ).width() <= "600") {
				if($(this).siblings().size() > 0 ) {
					$(this).siblings().slideToggle("fast")
					$(this).children(".toggle").html($(this).children(".toggle").html() == 'close' ? 'expand' : 'close');
				}
			}
		});
	});
	</script>

</head>

<body>

	<?php
	if (isset($_GET['error'])) {
		echo '<p class="error">Erreur de connection!</p>';
	}
	if (isset($_GET['err'])) {
		echo '<p class="error">Erreur de connection!</p>';
	}
	?>
	<?php
	if (!empty($error_msg)) {
		echo $error_msg;
	}
	?>

	<!-- Begin Body -->
	<header>
		<div id="logo" class="menuUp">
			<h1>Big Slip Shop</h1>
		</div>
		<nav>
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a>panier<span class="toggle">Expand</span><span class="caret"></span></a>
					<nav>
						<ul>
							<div class="toto">
								panier
							</div>
						</ul>
					</nav>
				</li>
				<li>
					<a>login <span class="toggle">Expand</span><span class="caret"></span></a>
					<nav>
						<ul>
							<?php if (login_check() != true) : ?>
							<form class="log" role="form" method="post" action="includes/process_login.php" accept-charset="UTF-8" id="login-nav">
								<div class="form-group">
									<label class="sr-only text-center" for="exampleInputEmail2">Email</label>
									<input name="email" type="email" class="form-control" id="exampleInputEmail2" placeholder="Email" required>
								</div>
								<div class="form-group">
									<label class="sr-only text-center" for="exampleInputPassword2">Mot de passe</label>
									<input name="password" id="password" type="password" class="form-control" id="exampleInputPassword2" onkeypress="if (event.keyCode == 13)
									{document.getElementById('bo').click(); return false;}" placeholder="Mot de passe" required>
								</div>
								<div class="form-group">
									<button type="button" id="bo" class="btn btn-primary btn-block" onclick="return formhash(this.form, this.form.password);" >connexion</button>
								</div>
								<div class="form-group">
									<div class="help-block text-center"><a href="register.php">Pas encore membre ?</a></div>
								</div>
							</form>
							<?php else: ?>
								<div id="log" style="text-align: right; color: #ff0000">
								<?php echo "Bonjour ".htmlentities($_SESSION['username'])."\n"; ?>
								<a href="includes/logout.php">déconnection</a>.
								</div>
							<?php endif ?>
						</ul>
					</nav>
				</li>
			</ul>
		</nav>
	</header>
<div class="main-body">
	<div class="left-col">
		<nav>
			<ul class="nav">
				<!--/////////////////////////olivier///////////////////////////-->
				<li>
					<a href="../index.php">Accueil</a>
				</li>
				<li>
					<a href="../homme.php">Homme</a>
				</li>
				<li>
					<a href="../femme.php">Femme</a>
				</li>
				<li>
					<a href="../enfant.php">Enfant</a>
				</li>
				<li>
					<a href="../vip.php">VIP</a>
				</li>
				<li>
					<a href="../aboutus.php">A propos</a>
				</li>
				<li>
					<a href="./contact.php">Contact</a>
				</li>
				<!--///////////////////////////////////////////////////////////-->
			</ul>
		</nav>
	</div>
	<div class="main-col">
		<?php $con = mysqli_connect($servername, $username, $password, "eshop");
		if (!$con)
			die("Connection failed: " . mysqli_connect_error());
		$prep_stmt = "SELECT name, price, stock, img, cat from shop;";
		$stmt = mysqli_prepare($con, $prep_stmt);

		// check existing email
		if ($stmt) {
			mysqli_stmt_execute($stmt);
			mysqli_store_result($con);
			mysqli_stmt_bind_result($stmt,$nom, $prix, $stock, $img, $cat);

			while (mysqli_stmt_fetch($stmt)){
				;?>
				<img src="data:image/;base64,<?php echo $img?>">
				<?php
			}
		}
		mysqli_close($con);?>
<!--	////////////////////////// olivier ////////////////////////////////////-->
<?php
		if (isset($_SESSION['costumerID']))
			$_POST['costumerID'] = $_SESSION['costumerID'];
		if ($_SESSION['cart'] != $_POST['cart'] && isset($_POST['cart']))
			$_SESSION['cart'] = $_POST['cart'];





?>

<p>Acceder au panier <a href="cart.php">clique ici</a> </p>

	<form method="post" action="cart.php">
		<div>
			<div class="city">
				<img  class="image" SRC="img/homme L.jpg" alt="homme L" title="homme L"><BR />
				<input type="number" name ="hommel" value="0" min="0" max="64"/><BR />
			</div>
			<div class="city">
				<img class="image" SRC="img/homme M.jpg" alt="homme M" title="homme M"><BR />
				<input type="number" name="hommem" value="0" min="0" max="64"/>
			</div>
			<div class="city">
				<img class="image" SRC="img/homme S.jpg" alt="homme S" title="homme S">
				<input type="number" name="hommes" value="0" min="0" max="64"/>
			</div>
		</div>
		<div>
			<div class="city">
				<img  class="image" SRC="img/femme L.jpg" alt="femme L" title="femme L"><BR />
				<input type="number" name ="femmel" value="0" min="0" max="64"/><BR />
			</div>
			<div class="city">
				<img class="image" SRC="img/femme M.jpg" alt="femme M" title="femme M"><BR />
				<input type="number" name="femmem" value="0" min="0" max="64"/>
			</div>
			<div class="city">
				<img class="image" SRC="img/femme S.jpg" alt="femme S" title="femme S">
				<input type="number" name="femmes" value="0" min="0" max="64"/>
			</div>
		</div>
		<div>
			<div class="city">
				<img  class="image" SRC="img/enfant L.jpg" alt="enfant L" title="enfant L"><BR />
				<input type="number" name ="enfantl" value="0" min="0" max="64"/><BR />
			</div>
			<div class="city">
				<img class="image" SRC="img/enfant M.jpg" alt="enfant M" title="enfant M"><BR />
				<input type="number" name="enfantm" value="0" min="0" max="64"/>
			</div>
			<div class="city">
				<img class="image" SRC="img/enfant S.jpg" alt="enfant S" title="enfant S">
				<input type="number" name="enfants" value="0" min="0" max="64"/>
			</div>
		</div>
		<div>
			<div class="city">
				<img  class="image" SRC="img/vip L.jpg" alt="vip L" title="vip L"><BR />
				<input type="number" name ="vipl" value="0" min="0" max="64"/><BR />
			</div>
			<div class="city">
				<img class="image" SRC="img/vip M.jpg" alt="vip M" title="vip M"><BR />
				<input type="number" name="vipm" value="0" min="0" max="64"/>
			</div>
			<div class="city">
				<img class="image" SRC="img/vip S.jpg" alt="vip S" title="vip S">
				<input type="number" name="vips" value="0" min="0" max="64"/>
			</div>
		</div>
		<input type="submit" value="valider">
	</form>





<!--	/////////////////////////////////////////////////////////////////////////-->
	</div>
</div>
<div class="footer">
            <p>Copyright (c) 2016</p>
        </div>


</body>
</html>
