<?php
include_once("includes/db_connect.php");
include_once("includes/fonctions.php");
sec_session_start();
?>
<!DOCTYPE html PUBLIC>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no" />
	<title>Slip-Shop</title>
	<link rel="stylesheet" href="styles/style.css">
	<script type="text/JavaScript" src="js/forms.js"></script>
	<script type="text/JavaScript" src="js/sha512.js"></script>
	<script>
	$(document).ready(function() {
		$("#navToggle a").click(function(e){
			e.preventDefault();

			$("header > nav").slideToggle("medium");
			$("#logo").toggleClass("menuUp menuDown");
		});

		$(window).resize(function() {
			if($( window ).width() >= "600") {
				$("header > nav").css("display", "block");

				if($("#logo").attr('class') == "menuDown") {
					$("#logo").toggleClass("menuUp menuDown");
				}
			}
			else {
				$("header > nav").css("display", "none");
			}
		});

		$("header > nav > ul > li > a").click(function(e) {
			if($( window ).width() <= "600") {
				if($(this).siblings().size() > 0 ) {
					$(this).siblings().slideToggle("fast")
					$(this).children(".toggle").html($(this).children(".toggle").html() == 'close' ? 'expand' : 'close');
				}
			}
		});
	});
	</script>

</head>

<body>

	<?php
	if (isset($_GET['error'])) {
		echo '<p class="error">Erreur de connection!</p>';
	}
	if (isset($_GET['err'])) {
		echo '<p class="error">Erreur de connection!</p>';
	}
	?>
	<?php
	if (!empty($error_msg)) {
		echo $error_msg;
	}
	?>

	<!-- Begin Body -->
	<header>
		<div id="logo" class="menuUp">
			<h1>Big Slip Shop</h1>
		</div>
		<nav>
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a>panier<span class="toggle">Expand</span><span class="caret"></span></a>
					<nav>
						<ul>
							<div class="toto">
								panier
							</div>
						</ul>
					</nav>
				</li>
				<li>
					<a>login <span class="toggle">Expand</span><span class="caret"></span></a>
					<nav>
						<ul>
							<?php if (login_check() != true) : ?>
							<form class="log" role="form" method="post" action="includes/process_login.php" accept-charset="UTF-8" id="login-nav">
								<div class="form-group">
									<label class="sr-only text-center" for="exampleInputEmail2">Email</label>
									<input name="email" type="email" class="form-control" id="exampleInputEmail2" placeholder="Email" required>
								</div>
								<div class="form-group">
									<label class="sr-only text-center" for="password">Mot de passe</label>
									<input name="password" id="password" type="password" class="form-control"  onkeypress="if (event.keyCode == 13)
									{document.getElementById('bo').click(); return false;}" placeholder="Mot de passe" required>
								</div>
								<div class="form-group">
									<button type="button" id="bo" class="btn btn-primary btn-block" onclick="return formhash(this.form, this.form.password);" >connexion</button>
								</div>
								<div class="form-group">
									<div class="help-block text-center"><a href="register.php">Pas encore membre ?</a></div>
								</div>
							</form>
							<?php else: ?>
								<div id="log" style="text-align: right; color: #ff0000">
								<?php echo "Bonjour ".htmlentities($_SESSION['username'])."\n"; ?>
								<a href="includes/logout.php">déconnection</a>.
								</div>
							<?php endif ?>
						</ul>
					</nav>
				</li>
			</ul>
		</nav>
	</header>
<div class="main-body">
	<div class="left-col">
		<nav>
			<ul class="nav">
				<li>
					<a href="./index.php">Accueil</a>
				</li>
				<li>
					<a href="./map.php">Carte des membres</a>
				</li>
				<li>
					<a href="./chasseur.php">Fiche chasseur</a>
				</li>
				<li>
					<a href="./cogneur.php">Fiche cogneur</a>
				</li>
				<li>
					<a href="./guerrier.php">Fiche guerrier</a>
				</li>
				<li>
					<a href="./scout.php">Fiche scout</a>
				</li>
				<li>
					<a href="./soldat.php">Fiche soldat</a>
				</li>
				<li>
					<a href="./tireur.php">Fiche tireur</a>
				</li>
			</ul>
		</nav>
	</div>
	<div class="main-col">
		<?php if (login_check($mysqli) == true && check_ad($mysqli) == true) {
			echo "<h2 id='sec0'>Bonjour ".$_SESSION['username'].", vous êtes administrateur.\n</h2>";?>
			<form class="log" role="form" action="admin.php" method="post" enctype="multipart/form-data">
				<div class="form-group">
					<label for="name">nom d article</label>
				<input type="text" name="name" placeholder="name" required>
				</div>
				<div class="form-group">
					<label for="price">prix</label>
				<input type="text" name="price" placeholder="price"  required>
				</div>
				<div class="form-group">
					<label for="stock">stock</label>
				<input type="text" name="stock"  placeholder="stock" required>
				</div>
				<div class="form-group">
					<label for="photo">image</label>
				<input type="file" name="photo" placeholder="photo"  required>
				</div>
				<div class="form-group">
					<label for="cat">catégories séparés par espace</label>
				<input type="text" name="cat"  placeholder="cat" required>
				</div>
				<div class="form-group">
				<button class="btn btn-primary btn-block" type="button" name="val" onclick="return adminadd(this.form, this.form.name, this.form.price, this.form.stock, this.form.photo, this.form.cat)">valider</button>
				</div>
			</form>

			<?php
				if (isset($_POST['name'], $_POST['price'], $_POST['stock'], $_POST['cat'], $_FILES['photo'])) {

					$name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
					$price = filter_input(INPUT_POST, 'price', FILTER_SANITIZE_NUMBER_INT);
					$stock = filter_input(INPUT_POST, 'stock', FILTER_SANITIZE_NUMBER_INT);
					$cat = filter_input(INPUT_POST, 'cat', FILTER_SANITIZE_STRING);
					$photo = filter_input(INPUT_POST, 'photo', FILTER_SANITIZE_STRING);
					$cat = explode(' ', $cat);
					for ($i=0; $i < count($cat); $i++) {
						$cate .= $cat[$i]."|";
					}
					$allowed =  array('gif','png' ,'jpg', 'jpeg');
					$filename = $_FILES['photo']['name'];
					$ext = pathinfo($filename, PATHINFO_EXTENSION);
					if(!in_array($ext,$allowed) ) {
    					$error_msg .= '<p class="error">bad extension.</p>';
					}
					else{
						$tmp = base64_encode(file_get_contents($_FILES['photo']['tmp_name']));
					}

					$con = mysqli_connect($servername, $username, $password, "eshop");
					if (!$con)
						die("Connection failed: " . mysqli_connect_error());
					$prep_stmt = "INSERT into shop (name, price, stock, img, cat) VALUES (?, ?, ?, '$tmp', ?);";
					$stmt = mysqli_prepare($con, $prep_stmt);

					// check existing email
					if ($stmt) {
						mysqli_stmt_bind_param($stmt, 'siis', $name, $price, $stock, $cate);
						if (! mysqli_stmt_execute($stmt)) {
							mysqli_close($con);
							header('Location: ../index.php?err=Registration failure: INSERT');
						}
						else {
							mysqli_close($con);
						}
					}
					//header('Location: ./admin.php');

				}?>
				<form class="log" role="form" action="admin.php" method="post">
					<?php
					$con = mysqli_connect($servername, $username, $password, "eshop");
					if (!$con)
						die("Connection failed: " . mysqli_connect_error());
					$prep_stmt = "SELECT username from members where admin = 0;";
					$stmt = mysqli_prepare($con, $prep_stmt);

					// check existing email
					if ($stmt) {
						mysqli_stmt_execute($stmt);
						mysqli_store_result($con);
						mysqli_stmt_bind_result($stmt,$nom);

						while (mysqli_stmt_fetch($stmt)){
							;?>
							<?php echo $nom;?>
							<div class="form-group">
							<label for="checkad[]">rendre admin</label>
							<input type="checkbox" name="checkad[]" id="checkad[]" value="<?php echo $nom;?>">
							</div>
							<div class="form-group">
							<label for="checkdel[]">supprimer</label>
							<input type="checkbox" name="checkdel[]" id="checkdel[]" value="<?php echo $nom;?>">
							</div>
							<?php
						}
					}
					mysqli_close($con);?>
					<div class="form-group">
						<button type="submit" id="to" class="btn btn-primary btn-block" >valider</button>
					</div>
				</form>
				<?php
				if (isset($_POST['checkad']) || isset($_POST['checkdel'])) {
					$_POST['checkad'] ? $ad = filter_var_array($_POST['checkad'], FILTER_SANITIZE_STRING) : NULL;
					$_POST['checkdel'] ? $del = filter_var_array($_POST['checkdel'], FILTER_SANITIZE_STRING) : NULL;
					if ($del){
					foreach (array_keys($del) as $i) {
						$con = mysqli_connect($servername, $username, $password, "eshop");
						if (!$con)
							die("Connection failed: " . mysqli_connect_error());
						$prep_stmt = "DELETE from members where username = '$del[$i]';";
						if ($stmt = mysqli_prepare($con,$prep_stmt)){
							if (!mysqli_stmt_execute($stmt)) {
								echo "error";
							}
							else {
								echo "succes";
							}
							mysqli_close($con);
						}
						else {
							echo "error2";
							mysqli_close($con);
						}
					}
				}
					if ($ad){
					foreach (array_keys($ad) as $i) {
						$con = mysqli_connect($servername, $username, $password, "eshop");
						if (!$con)
							die("Connection failed: " . mysqli_connect_error());
						$prep_stmt = "UPDATE members SET admin=1 where username = '$ad[$i]';";
						if ($stmt = mysqli_prepare($con,$prep_stmt)){
							if (!mysqli_stmt_execute($stmt)) {
								echo "error";
							}
							else {
								echo "succes";
								echo "<meta http-equiv='refresh' content='0'>";
							}
							mysqli_close($con);
						}
						else {
							echo "error2";
							mysqli_close($con);
						}
					}
				}
			}

			} else {
			?>
			<p>
				<span class="error">Vous n'êtes pas authorisé à voir cette page.</span> <a href="index.php">d'acceuil</a>.
			</p>
			<?php;
		}
		?>


	</div>
</div>
<div class="footer">
            <p>Copyright (c) 2016</p>
        </div>


</body>
</html>
