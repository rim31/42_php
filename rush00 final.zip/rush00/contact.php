<?php
include_once("includes/fonctions.php");
sec_session_start();
print_r($_SESSION['cart'])."\n";
// print_r($_SESSION);

?>
<form action="MAILTO:someone@example.com" method="post" enctype="text/plain">
Name:<br>
<input type="text" name="name" value="your name"><br>
E-mail:<br>
<input type="text" name="mail" value="your email"><br>
Comment:<br>
<!-- <input type="text" name="message" value="your comment"><br><br> -->
<textarea name="message" rows="8" cols="45" value="your message">
votre message :
</textarea><br />
<input type="submit" value="Send">
<input type="reset" value="Reset">
</form>
</body>
