<?php
include_once("includes/fonctions.php");
include_once 'includes/register.inc.php';
sec_session_start();
?>
<!DOCTYPE html PUBLIC>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no" />
	<title>Slip-Shop</title>
	<link rel="stylesheet" href="styles/style.css">
	<script type="text/JavaScript" src="js/forms.js"></script>
	<script type="text/JavaScript" src="js/sha512.js"></script>
	<script>
	$(document).ready(function() {
		$("#navToggle a").click(function(e){
			e.preventDefault();

			$("header > nav").slideToggle("medium");
			$("#logo").toggleClass("menuUp menuDown");
		});

		$(window).resize(function() {
			if($( window ).width() >= "600") {
				$("header > nav").css("display", "block");

				if($("#logo").attr('class') == "menuDown") {
					$("#logo").toggleClass("menuUp menuDown");
				}
			}
			else {
				$("header > nav").css("display", "none");
			}
		});

		$("header > nav > ul > li > a").click(function(e) {
			if($( window ).width() <= "600") {
				if($(this).siblings().size() > 0 ) {
					$(this).siblings().slideToggle("fast")
					$(this).children(".toggle").html($(this).children(".toggle").html() == 'close' ? 'expand' : 'close');
				}
			}
		});
	});
	</script>

</head>

<body>

	<?php
	if (isset($_GET['error'])) {
		echo '<p class="error">Erreur de connection!</p>';
	}
	?>
	<?php
	if (!empty($error_msg)) {
		echo $error_msg;
	}
	?>

	<!-- Begin Body -->
	<header>
		<div id="logo" class="menuUp">
			<h1>Big Slip Shop</h1>
		</div>
		<nav>
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="#">About</a></li>
				<li>
					<a href="#">login <span class="toggle">Expand</span><span class="caret"></span></a>
					<nav>
						<ul>
							<?php if (!login_check()): ?>
							<form class="log" role="form" method="post" action="includes/process_login.php" accept-charset="UTF-8" id="login-nav">
								<div class="form-group">
									<label class="sr-only text-center" for="exampleInputEmail2">Email</label>
									<input name="email" type="email" class="form-control" id="exampleInputEmail2" placeholder="Email" required>
								</div>
								<div class="form-group">
									<label class="sr-only text-center" for="exampleInputPassword2">Mot de passe</label>
									<input name="password" id="password" type="password" class="form-control" id="exampleInputPassword2" onkeypress="if (event.keyCode == 13)
									{document.getElementById('bo').click(); return false;}" placeholder="Mot de passe" required>
								</div>
								<div class="form-group">
									<button type="button" id="bo" class="btn btn-primary btn-block" onclick="return formhash(this.form, this.form.password);" >connexion</button>
								</div>
								<div class="form-group">
									<div class="help-block text-center"><a href="register.php">Pas encore membre ?</a></div>
								</div>
							</form>
							<?php else: ?>
								<div id="log" style="text-align: right; color: #ff0000">
								<?php echo "Bonjour ".htmlentities($_SESSION['username'])."\n"; ?>
								<a href="includes/logout.php">déconnection</a>.
								</div>
							<?php endif ?>
						</ul>
					</nav>
				</li>
			</ul>
		</nav>
	</header>
<div class="main-body">
	<div class="left-col">
		<nav>
			<ul class="nav">
				<li>
					<a href="../index.php">Accueil</a>
				</li>
				<li>
					<a href="../map.php">Carte des membres</a>
				</li>
				<li>
					<a href="../chasseur.php">Fiche chasseur</a>
				</li>
				<li>
					<a href="../cogneur.php">Fiche cogneur</a>
				</li>
				<li>
					<a href="../guerrier.php">Fiche guerrier</a>
				</li>
				<li>
					<a href="../scout.php">Fiche scout</a>
				</li>
				<li>
					<a href="../soldat.php">Fiche soldat</a>
				</li>
				<li>
					<a href="../tireur.php">Fiche tireur</a>
				</li>
			</ul>
		</nav>
	</div>
	<div class="main-col">
		<hr class="col-md-12">
		Le pseudo doit contenir uniquement des lettres majuscules ou minuscules ou underscores.<br>
		<hr class="col-md-12">
		Email doit avoir un format valide jeu.<br>
		<hr class="col-md-12">
		Email doit avoir un format valide jeu.<br>
		<hr class="col-md-12">
		Le mot de passe doit contenir au moins 6 caractères.<br>
		<hr class="col-md-12">

		<div class="row">
			<div class="col-md-12">
				<div class="panel panel-default">
					<div class="panel-heading" id="title"><h3>Le mot de passe doit contenir:<br></h3></div>
					<div class="panel-body">
						-Au moins un lettre majuscule (A..Z)<br>
						-Au moins un lettre minuscule (a..z)<br>
						-Au moins un chiffre (0..9)<br>
					</div>
				</div>
			</div>
		</div>
		<hr class="col-md-12">
		le mot de passe et la confirmation doivent être identiques<br>
		<hr class="col-md-12">


		<div class="col-md-12" id="register">
			<form class="log" role="form" method="post" action="<?php echo esc_url($_SERVER['PHP_SELF']); ?>" accept-charset="UTF-8" name="registration_form">
				<div class="form-group" id="topf">
					<label class="sr-only text-center" for="username">Pseudo:</label>
					<input type='text' name='username' id='username' class="form-control" placeholder="Pseudo" required>
				</div>
				<div class="form-group">
					<label class="sr-only text-center" for="email">Email:</label>
					<input type="email" name="email" id="email" class="form-control" placeholder="Email" required>
				</div>
				<div class="form-group">
					<label class="sr-only text-center" for="adresse">Adresse:</label>
					<input type='text' name='adresse' id='adresse' class="form-control" placeholder="Adresse" required>
				</div>
				<div class="form-group">
					<label class="sr-only text-center" for="cp">Code postal:</label>
					<input type='text' name='cp' id='cp' class="form-control" placeholder="code postal" required>
				</div>
				<div class="form-group">
					<label class="sr-only text-center" for="ville">Ville:</label>
					<input type='ville' name='ville' id='ville' class="form-control" placeholder="Ville" required>
				</div>
				<div class="form-group">
					<label class="sr-only text-center" for="password">Mot de passe:</label>
					<input type="password" name="password" id="password" class="form-control" placeholder="Mot de passe" required>
				</div>
				<div class="form-group">
					<label class="sr-only text-center" for="confirmpwd">Confirmation:</label>
					<input type="password" name="confirmpwd" id="confirmpwd" onkeypress="if (event.keyCode == 13) {document.getElementById('lo').click(); return false;}" class="form-control" placeholder="Mot de passe" required>
				</div>
				<div class="form-group">
					<button class="btn btn-primary btn-block" type="button" id="lo" onclick="return regformhash(this.form, this.form.username, this.form.email, this.form.password, this.form.confirmpwd, this.form.adresse, this.form.cp, this.form.ville);" >Enregistrer</button>
				</div>
				<div class="form-group">
					<div class="help-block text-center"><a href="index.php">Retour à la page de connexion</a></div>
				</div>
			</form>
		</div>
	</div>
</div>
<div class="footer">
            <p>Copyright (c) 2008</p>
        </div>


</body>
</html>
