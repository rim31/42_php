<?php
$servername = "localhost";
$username = "root";
$password = "root";

$con = mysqli_connect($servername, $username, $password);
if (!$con)
	die("Connection failed: " . mysqli_connect_error());

$sql = "CREATE DATABASE eshop;";
if (mysqli_query($con, $sql))
	echo "Database created successfully\n";
else
	echo "Error creating database: " . mysqli_error($con);

$sql2 = "CREATE TABLE IF NOT EXISTS `shop` (`id` int(10) unsigned NOT NULL AUTO_INCREMENT,`name` varchar(240) COLLATE utf8_unicode_ci NOT NULL,`price` decimal(10) unsigned NOT NULL,`stock` int(10) unsigned NOT NULL,`img` LONGBLOB NOT NULL,`cat` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,PRIMARY KEY (`id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1;";
if(mysqli_select_db ($con, "eshop") && mysqli_query($con, $sql2))
	echo "Table created successfully\n";
else
	echo "Error creating table: " . mysqli_error($con);

$sql3 = "CREATE TABLE IF NOT EXISTS `members` (`id` int(11) NOT NULL AUTO_INCREMENT,`username` varchar(30) COLLATE utf8_unicode_ci NOT NULL,`email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,`password` char(128) COLLATE utf8_unicode_ci NOT NULL,`admin` tinyint(1) NOT NULL DEFAULT '0',`address` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,PRIMARY KEY (`id`)) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1;";
if (mysqli_query($con, $sql3)) {
	echo "Base2 created successfully";
} else {
	echo "Error creating Base2: " . mysqli_error($con);
}
mysqli_close($con);
?>
