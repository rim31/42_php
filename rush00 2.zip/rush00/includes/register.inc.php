<?php
include_once 'db_connect.php';

$error_msg = "";

if (isset($_POST['username'], $_POST['email'], $_POST['p'], $_POST['adresse'], $_POST['cp'], $_POST['ville'])) {
	// Sanitize and validate the data passed in
	$username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
	$email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
	$email = filter_var($email, FILTER_VALIDATE_EMAIL);
	$ad = filter_input(INPUT_POST, 'adresse', FILTER_SANITIZE_STRING);
	$ad2 = filter_input(INPUT_POST, 'cp', FILTER_SANITIZE_STRING);
	$ad3 = filter_input(INPUT_POST, 'ville', FILTER_SANITIZE_STRING);
	$adress = $ad."|".$ad2."|".$ad3;
	if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
		// Not a valid email
		$error_msg .= '<p class="error">Email invalide</p>';
	}
	if (strlen($adress) > 240)
	{
		$error_msg .= '<p class="error">Adresse trop longue.</p>';
	}

	$password = filter_input(INPUT_POST, 'p', FILTER_SANITIZE_STRING);
	if (strlen($password) != 128) {
		// The hashed pwd should be 128 characters long.
		// If it's not, something really odd has happened
		$error_msg .= '<p class="error">Mot passe non conforme.</p>';
	}

	// Username validity and password validity have been checked client side.
	// This should should be adequate as nobody gains any advantage from
	// breaking these rules.
	//
	$con = mysqli_connect($servername, $username, $password, "eshop");
	if (!$con)
		die("Connection failed: " . mysqli_connect_error());
	$prep_stmt = "SELECT id FROM members WHERE email = ? LIMIT 1;";
	$stmt = mysqli_prepare($con, $prep_stmt);

	// check existing email
	if ($stmt) {
		mysqli_stmt_bind_param($stmt, 's', $email);
		mysqli_stmt_execute($stmt);
		mysqli_store_result($con);

		if (mysqli_stmt_fetch($stmt)) {
			// A user with this email address already exists
			$error_msg .= '<p class="error">Email déjà utiliser.</p>';
		}
	} else {
		$error_msg .= '<p class="error">Database error Line 39</p>';
	}
	mysqli_close($con);
	$con = mysqli_connect($servername, $username, $password, "eshop");
	if (!$con)
		die("Connection failed: " . mysqli_connect_error());
	// check existing username
	$prep_stmt = "SELECT id FROM members WHERE username = ? LIMIT 1";
	$stmt = mysqli_prepare($con, $prep_stmt);
	if ($stmt) {
		mysqli_stmt_bind_param($stmt, 's', $username);
		mysqli_stmt_execute($stmt);
		mysqli_store_result($con);

		if (mysqli_stmt_fetch($stmt)) {
			// A user with this username already exists
			$error_msg .= '<p class="error">Pseudo déjà utiliser</p>';
		}
	} else {
		$error_msg .= '<p class="error">Database error line 55</p>';
	}

	// TODO:
	// We'll also have to account for the situation where the user doesn't have
	// rights to do registration, by checking what type of user is attempting to
	// perform the operation.

	mysqli_close($con);
	$con = mysqli_connect($servername, $username, $password, "eshop");
	if (!$con)
		die("Connection failed: " . mysqli_connect_error());
	if (empty($error_msg)) {

		// Create hashed password using the password_hash function.
		// This function salts it with a random salt and can be verified with
		// the password_verify function.
		$password = password_hash($password, PASSWORD_BCRYPT);

		// Insert the new user into the database
		$stmt = "INSERT INTO members (username, email, password, address) VALUES (?, ?, ?, ?)";
		if ($insert_stmt = mysqli_prepare($con, $stmt)) {
			mysqli_stmt_bind_param($insert_stmt, 'ssss', $username, $email, $password, $adress);
			// Execute the prepared query.
			if (! mysqli_stmt_execute($insert_stmt)) {
				mysqli_close($con);
				header('Location: ../index.php?err=Registration failure: INSERT');
			}
			else {
				mysqli_close($con);
			}
		}
		header('Location: ./index.php');
	}
}
?>
