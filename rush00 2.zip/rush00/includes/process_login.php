<?php
include_once 'db_connect.php';
include_once 'fonctions.php';
sec_session_start(); // Our custom secure way of starting a PHP session.
$error_msg = "";
if (isset($_POST['email'], $_POST['p'])) {
	$email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
	$password = $_POST['p']; // The hashed password.

	if (login($email, $password) == true) {
		// Login success
		header("Location: ../index.php");
		exit();
	} else {
		// Login failed
		header('Location: ../index.php?error=1');
		exit();
	}
} else {
	// The correct POST variables were not sent to this page.
	header('Location: ../index.php?err=Could not process login');
	exit();
}
