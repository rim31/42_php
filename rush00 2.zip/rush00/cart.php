<?php
include_once("includes/fonctions.php");
sec_session_start();

function name_art($name)
{
	if ($name == 'hommel')
		$prod = "homme large";
	if ($name == 'hommem')
		$prod = "homme medium";
	if ($name == 'hommes')
		$prod = "homme small";
	if ($name == 'femmel')
		$prod = "femme large";
	if ($name == 'femmem')
		$prod = "femme medium";
	if ($name == 'femmes')
		$prod = "femme small";
	if ($name == 'enfantl')
		$prod = "enfant large";
	if ($name == 'enfantm')
		$prod = "enfant medium";
	if ($name == 'enfant small')
		$prod = "enfant";
	if ($name == 'vipl')
		$prod = "vip large";
	if ($name == 'vipm')
		$prod = "vip medium";
	if ($name == 'vips')
		$prod = "vip small";
	return($prod);
}

$cart = array (
    "h_l"  => array("name" => "hommel", "price" => "99", "qty" => $_POST['hommel'], "stock" => "10", "cat" => "homme", 'subcat' => "l"),
	"h_m"  => array("name" => "hommem", "price" => "79", "qty" => $_POST['hommem'], "stock" => "9", "cat" => "homme", 'subcat' => "m"),
	"h_s"  => array("name" => "hommes", "price" => "59", "qty" => $_POST['hommes'], "stock" => "7", "cat" => "homme", 'subcat' => "s"),
	"f_l"  => array("name" => "femmel", "price" => "89", "qty" => $_POST['femmel'], "stock" => "10", "cat" => "femme", 'subcat' => "l"),
	"f_m"  => array("name" => "femmem", "price" => "69", "qty" => $_POST['femmem'], "stock" => "9", "cat" => "femme", 'subcat' => "m"),
	"f_s"  => array("name" => "femmes", "price" => "49", "qty" => $_POST['femmes'], "stock" => "7", "cat" => "femme", 'subcat' => "s"),
	"e_l"  => array("name" => "enfantl", "price" => "59", "qty" => $_POST['enfantl'], "stock" => "10", "cat" => "enfant", 'subcat' => "l"),
	"e_m"  => array("name" => "enfantm", "price" => "49", "qty" => $_POST['enfantm'], "stock" => "9", "cat" => "enfant", 'subcat' => "m"),
	"e_s"  => array("name" => "enfants", "price" => "39", "qty" => $_POST['enfants'], "stock" => "7", "cat" => "enfant", 'subcat' => "s"),
	"v_l"  => array("name" => "vipl", "price" => "59", "qty" => $_POST['vipl'], "stock" => "10", "cat" => "vip", 'subcat' => "l"),
	"v_m"  => array("name" => "vipm", "price" => "49", "qty" => $_POST['vipm'], "stock" => "9", "cat" => "vip", 'subcat' => "m"),
	"v_s"  => array("name" => "vips", "price" => "39", "qty" => $_POST['vips'], "stock" => "7", "cat" => "vip", 'subcat' => "s")
);
//recuperer la quantite du stock dans la base de donnees
$_SESSION['cart'] = $cart;

// $_SESSION['cart'] = $_POST['cart'];
// $_SESSION['hommel'] = $_POST['hommel'];
// $_SESSION['hommem'] = $_POST['hommem'];
// $_SESSION['hommes'] = $_POST['hommes'];
// $_SESSION['femmel'] = $_POST['femmel'];
// $_SESSION['femmem'] = $_POST['femmem'];
// $_SESSION['femmes'] = $_POST['femmes'];
// $_SESSION['enfantl'] = $_POST['enfantl'];
// $_SESSION['enfantm'] = $_POST['enfantm'];
// $_SESSION['enfants'] = $_POST['enfants'];
// $_SESSION['vipl'] = $_POST['vipl'];
// $_SESSION['vipm'] = $_POST['vipm'];
// $_SESSION['vips'] = $_POST['vips'];

echo "Vous avez acheté : <br />";
$total = 0;
foreach ($_SESSION["cart"] as $sous_tableau)
{
	foreach ($sous_tableau as $key => $nb)
	{
		if ($key == "qty" && $nb != 0)
		{
			echo "article : ".name_art($sous_tableau['name']). " x ".$nb."  x ".$sous_tableau['price']." ==> ";
			echo $nb * $sous_tableau['price']." euros<br/>";
			$total += $nb * $sous_tableau['price'];
		}
	}
}
echo "TOTAL : ".$total." euros<br />"

?>
<html>
	<body>
		<form action="pay.php" method="post">
			<input type="submit" value="Paiement">
			<input type="reset" value="Annuler">
		</form>
	</body>
</html>
