<?php
include_once("includes/db_connect.php");
include_once("includes/fonctions.php");
sec_session_start();
?>
<!DOCTYPE html PUBLIC>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no" />
	<title>Slip-Shop</title>
	<link rel="stylesheet" href="styles/style.css">
	<script type="text/JavaScript" src="js/forms.js"></script>
	<script type="text/JavaScript" src="js/sha512.js"></script>
	<script>
	$(document).ready(function() {
		$("#navToggle a").click(function(e){
			e.preventDefault();

			$("header > nav").slideToggle("medium");
			$("#logo").toggleClass("menuUp menuDown");
		});

		$(window).resize(function() {
			if($( window ).width() >= "600") {
				$("header > nav").css("display", "block");

				if($("#logo").attr('class') == "menuDown") {
					$("#logo").toggleClass("menuUp menuDown");
				}
			}
			else {
				$("header > nav").css("display", "none");
			}
		});

		$("header > nav > ul > li > a").click(function(e) {
			if($( window ).width() <= "600") {
				if($(this).siblings().size() > 0 ) {
					$(this).siblings().slideToggle("fast")
					$(this).children(".toggle").html($(this).children(".toggle").html() == 'close' ? 'expand' : 'close');
				}
			}
		});
	});
	</script>

</head>

<body>

	<?php
	if (isset($_GET['error'])) {
		echo '<p class="error">Erreur de connection!</p>';
	}
	if (isset($_GET['err'])) {
		echo '<p class="error">Erreur de connection!</p>';
	}
	?>
	<?php
	if (!empty($error_msg)) {
		echo $error_msg;
	}
	?>

	<!-- Begin Body -->
	<header>
		<div id="logo" class="menuUp">
			<h1>Big Slip Shop</h1>
		</div>
		<nav>
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="#">About</a></li>
				<li>
					<a href="#">login <span class="toggle">Expand</span><span class="caret"></span></a>
					<nav>
						<ul>
							<?php if (login_check() != true) : ?>
							<form class="log" role="form" method="post" action="includes/process_login.php" accept-charset="UTF-8" id="login-nav">
								<div class="form-group">
									<label class="sr-only text-center" for="exampleInputEmail2">Email</label>
									<input name="email" type="email" class="form-control" id="exampleInputEmail2" placeholder="Email" required>
								</div>
								<div class="form-group">
									<label class="sr-only text-center" for="exampleInputPassword2">Mot de passe</label>
									<input name="password" id="password" type="password" class="form-control" id="exampleInputPassword2" onkeypress="if (event.keyCode == 13)
									{document.getElementById('bo').click(); return false;}" placeholder="Mot de passe" required>
								</div>
								<div class="form-group">
									<button type="button" id="bo" class="btn btn-primary btn-block" onclick="return formhash(this.form, this.form.password);" >connexion</button>
								</div>
								<div class="form-group">
									<div class="help-block text-center"><a href="register.php">Pas encore membre ?</a></div>
								</div>
							</form>
							<?php else: ?>
								<div id="log" style="text-align: right; color: #ff0000">
								<?php echo "Bonjour ".htmlentities($_SESSION['username'])."\n"; ?>
								<a href="includes/logout.php">déconnection</a>.
								</div>
							<?php endif ?>
						</ul>
					</nav>
				</li>
			</ul>
		</nav>
	</header>
<div class="main-body">
	<div class="left-col">
		<nav>
			<ul class="nav">
				<li>
					<a href="../index.php">Accueil</a>
				</li>
				<li>
					<a href="../map.php">Carte des membres</a>
				</li>
				<li>
					<a href="../chasseur.php">Fiche chasseur</a>
				</li>
				<li>
					<a href="../cogneur.php">Fiche cogneur</a>
				</li>
				<li>
					<a href="../guerrier.php">Fiche guerrier</a>
				</li>
				<li>
					<a href="../scout.php">Fiche scout</a>
				</li>
				<li>
					<a href="../soldat.php">Fiche soldat</a>
				</li>
				<li>
					<a href="../tireur.php">Fiche tireur</a>
				</li>
			</ul>
		</nav>
	</div>
	<div class="main-col">
		<?php if (login_check($mysqli) == true && check_ad($mysqli) == true) {
			echo "<h2 id='sec0'>Bonjour ".$_SESSION['username'].", vous êtes administrateur.\n</h2>";?>
			<form class="" action="admin.php" method="post">
				<input type="text" name="name" placeholder="name" required/>
				<input type="text" name="price" placeholder="price"  required/>
				<input type="text" name="stock"  placeholder="stock" required/>
				<input type="file" name="photo" placeholder="photo"  required/>
				<input type="text" name="cat"  placeholder="cat" required/>
				<input type="button" name="val" value="valider" onclick="return adminadd(this.form, this.form.name, this.form.price, this.form.stock, this.form.photo, this.form.cat)">
			</form>

			<?php
				if (isset($_POST['name'], $_POST['price'], $_POST['stock'], $_POST['cat'], $_POST['photo'])) {
					print_r($_POST);
				}
		} else {
			?>
			<p>
				<span class="error">Vous n'êtes pas authorisé à voir cette page.</span> <a href="index.php">d'acceuil</a>.
			</p>
			<?php;
		}
		?>


	</div>
</div>
<div class="footer">
            <p>Copyright (c) 2008</p>
        </div>


</body>
</html>
